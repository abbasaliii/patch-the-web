"use strict";
(() => {
  // src/registry/patches/civic-apply.openpatch.json
  var civic_apply_openpatch_default = {
    schemaVersion: 1,
    id: "org.openpatch.civicapply-accessible-draft",
    name: "CivicApply: accessible & autosaved",
    summary: "Repairs the mobile application flow, preserves unfinished progress, adds accessible validation, and removes the obstructive survey.",
    version: "1.1.0",
    author: { name: "OpenPatch Community", verified: false },
    match: {
      hosts: ["localhost", "127.0.0.1"],
      paths: ["/demo/*"]
    },
    capabilities: [
      "layout",
      "accessibility",
      "local-storage",
      "keyboard-navigation",
      "validation",
      "hide-elements",
      "reorganize"
    ],
    operations: [
      {
        id: "hide-obstructive-survey",
        type: "hide",
        selector: ".survey-wall"
      },
      {
        id: "hide-conflicting-save-state",
        type: "hide",
        selector: ".draft-badge"
      },
      {
        id: "repair-page-width",
        type: "style",
        selector: ".application-shell",
        styles: {
          "max-width": "900px",
          width: "calc(100% - 32px)",
          margin: "0 auto",
          "grid-template-columns": "minmax(0, 1fr)",
          gap: "32px"
        }
      },
      {
        id: "repair-mobile-layout",
        type: "style",
        selector: ".application-shell",
        when: { maxWidth: 760 },
        styles: {
          display: "flex",
          "flex-direction": "column",
          width: "calc(100% - 24px)",
          gap: "16px"
        }
      },
      {
        id: "mobile-form-spacing",
        type: "style",
        selector: ".application-main",
        when: { maxWidth: 760 },
        styles: {
          padding: "20px",
          "border-radius": "18px"
        }
      },
      {
        id: "mobile-header-width",
        type: "style",
        selector: ".government-header, .session-warning",
        when: { maxWidth: 760 },
        styles: {
          width: "100%",
          "max-width": "100%",
          "padding-left": "16px",
          "padding-right": "16px",
          "flex-wrap": "wrap"
        }
      },
      {
        id: "mobile-preserve-agency-nav",
        type: "style",
        selector: ".government-header nav",
        when: { maxWidth: 760 },
        styles: {
          display: "flex",
          order: "3",
          width: "100%",
          "margin-left": "0",
          "overflow-x": "auto",
          "padding-bottom": "10px"
        }
      },
      {
        id: "mobile-content-width",
        type: "style",
        selector: ".application-heading, .progress-steps",
        when: { maxWidth: 760 },
        styles: {
          width: "calc(100% - 24px)",
          "max-width": "100%",
          "margin-left": "auto",
          "margin-right": "auto",
          "overflow-x": "auto"
        }
      },
      {
        id: "mobile-progress-gaps",
        type: "style",
        selector: ".progress-steps > i",
        when: { maxWidth: 760 },
        styles: {
          width: "42px",
          "margin-left": "6px",
          "margin-right": "6px"
        }
      },
      {
        id: "readable-fields",
        type: "style",
        selector: ".field-row",
        styles: {
          display: "grid",
          "grid-template-columns": "minmax(0, 1fr)",
          gap: "8px",
          "margin-bottom": "20px"
        }
      },
      {
        id: "move-help-before-form",
        type: "move",
        selector: ".help-card",
        target: "#benefits-form",
        position: "before"
      },
      {
        id: "help-card-layout",
        type: "style",
        selector: ".help-card",
        styles: {
          "margin-bottom": "20px",
          "background-color": "#effcf6",
          "border-color": "#b7ebd0"
        }
      },
      {
        id: "progress-semantics",
        type: "attributes",
        selector: "#progress-steps",
        attributes: {
          role: "group",
          "aria-label": "Application progress"
        }
      },
      {
        id: "progress-keyboard",
        type: "keyboardNavigation",
        container: "#progress-steps",
        items: "button",
        orientation: "horizontal",
        wrap: true
      },
      {
        id: "label-required-email",
        type: "attributes",
        selector: "#email",
        attributes: {
          "aria-required": "true",
          autocomplete: "email",
          inputmode: "email"
        }
      },
      {
        id: "label-required-name",
        type: "attributes",
        selector: "#full-name",
        attributes: {
          "aria-required": "true",
          autocomplete: "name"
        }
      },
      {
        id: "label-other-required-fields",
        type: "attributes",
        selector: "#household-size, #address",
        attributes: { "aria-required": "true" }
      },
      {
        id: "persist-draft",
        type: "persistForm",
        selector: "#benefits-form",
        key: "housing-support-draft-v1",
        include: ["input", "select", "textarea"],
        ttlMinutes: 1440,
        statusText: "Draft saved on this device for 24 hours"
      },
      {
        id: "accessible-validation",
        type: "validation",
        selector: "#benefits-form",
        fields: [
          {
            selector: "#full-name",
            rules: [
              { kind: "required", message: "Enter your full name so we can continue." },
              { kind: "minLength", value: 3, message: "Your full name must contain at least 3 characters." }
            ]
          },
          {
            selector: "#email",
            rules: [
              { kind: "required", message: "Enter an email address for application updates." },
              { kind: "email", message: "Enter an email address in the format name@example.com." }
            ]
          },
          {
            selector: "#household-size",
            rules: [
              { kind: "required", message: "Select the number of people in your household." }
            ]
          },
          {
            selector: "#address",
            rules: [
              { kind: "required", message: "Enter your current street address." }
            ]
          }
        ]
      }
    ],
    verify: [
      { type: "exists", selector: "#benefits-form", min: 1, max: 1 },
      { type: "exists", selector: "#progress-steps button", min: 3, max: 3 },
      { type: "exists", selector: ".help-card", min: 1, max: 1 },
      { type: "exists", selector: ".openpatch-save-status", min: 1, max: 1 },
      { type: "attribute", selector: ".survey-wall", name: "aria-hidden", value: "true" },
      { type: "attribute", selector: ".draft-badge", name: "aria-hidden", value: "true" },
      { type: "attribute", selector: "#progress-steps", name: "role", value: "group" },
      { type: "attribute", selector: "#email", name: "aria-required", value: "true" },
      { type: "attribute", selector: "#household-size", name: "aria-required", value: "true" },
      { type: "attribute", selector: "#address", name: "aria-required", value: "true" }
    ],
    changelog: "Hardened community repair: preserve mobile agency navigation, complete required-field semantics, add 24-hour draft expiry, and expand publication assertions."
  };

  // src/core/engine.ts
  var MAX_MATCHES = 100;
  var SENSITIVE_AUTOCOMPLETE = /(?:current-password|new-password|one-time-code|cc-|transaction-|webauthn)/i;
  function installTrustedUiStyles(document2) {
    if (document2.querySelector("style[data-openpatch-ui]")) return;
    const style = document2.createElement("style");
    style.dataset.openpatchUi = "true";
    style.textContent = `
    .openpatch-save-status {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      margin: 0 0 18px;
      padding: 8px 12px;
      border: 1px solid #b7ebd0;
      border-radius: 999px;
      color: #086647;
      background: #effcf6;
      font: 600 13px/1.2 ui-sans-serif, system-ui, sans-serif;
    }
    .openpatch-save-status::before { content: "\u2713"; }
    .openpatch-field-error {
      margin: 7px 0 0;
      color: #b42318;
      font: 600 14px/1.35 ui-sans-serif, system-ui, sans-serif;
    }
    [aria-invalid="true"] {
      border-color: #d92d20 !important;
      box-shadow: 0 0 0 3px rgba(217, 45, 32, .12) !important;
    }
  `;
    document2.head.append(style);
  }
  function selected(document2, selector) {
    return [...document2.querySelectorAll(selector)].slice(0, MAX_MATCHES);
  }
  function isEligibleField(element) {
    if (!["INPUT", "SELECT", "TEXTAREA"].includes(element.tagName)) return false;
    if (element.tagName === "INPUT" && ["password", "file", "hidden", "submit", "button", "reset", "image"].includes(element.type)) return false;
    if (SENSITIVE_AUTOCOMPLETE.test(element.getAttribute("autocomplete") || "")) return false;
    return !element.disabled;
  }
  function fieldKey(element, index) {
    return element.name || element.id || `field-${index}`;
  }
  function readField(element) {
    if (element.tagName === "INPUT" && ["checkbox", "radio"].includes(element.type)) return element.checked;
    return element.value;
  }
  function writeField(element, value) {
    if (element.tagName === "INPUT" && ["checkbox", "radio"].includes(element.type)) {
      if (typeof value === "boolean") element.checked = value;
    } else if (typeof value === "string") {
      element.value = value;
    }
  }
  function viewportMatches(operation, window2) {
    if (!operation.when) return true;
    const width = window2.innerWidth;
    return (operation.when.minWidth === void 0 || width >= operation.when.minWidth) && (operation.when.maxWidth === void 0 || width <= operation.when.maxWidth);
  }
  function setupPersistence(patch, operation, context, form) {
    const { document: document2, storage } = context;
    const fields = operation.include.flatMap((selector) => selected(form.ownerDocument, `${operation.selector} ${selector}`)).filter(isEligibleField);
    const uniqueFields = [...new Set(fields)].slice(0, 40);
    const storageKey = `openpatch:${patch.id}:${operation.key}`;
    const status = document2.createElement("p");
    status.className = "openpatch-save-status";
    status.dataset.openpatchOwned = "true";
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    status.textContent = operation.statusText;
    form.prepend(status);
    let restored = false;
    try {
      const raw = storage.getItem(storageKey);
      if (raw) {
        const stored = JSON.parse(raw);
        const savedAt = typeof stored.savedAt === "number" ? stored.savedAt : 0;
        const expired = Date.now() - savedAt > operation.ttlMinutes * 6e4;
        const values = stored.values && typeof stored.values === "object" && !Array.isArray(stored.values) ? stored.values : null;
        if (expired || !values) {
          storage.removeItem(storageKey);
          status.textContent = `Previous draft expired \xB7 ${operation.statusText}`;
        } else {
          uniqueFields.forEach((field, index) => writeField(field, values[fieldKey(field, index)]));
          status.textContent = `Draft restored \xB7 ${operation.statusText}`;
          restored = true;
        }
      }
    } catch {
      status.textContent = "Local draft storage is unavailable";
    }
    const save = () => {
      const snapshot = {};
      uniqueFields.forEach((field, index) => {
        snapshot[fieldKey(field, index)] = readField(field);
      });
      try {
        storage.setItem(storageKey, JSON.stringify({ savedAt: Date.now(), values: snapshot }));
        status.textContent = operation.statusText;
        status.dataset.state = "saved";
      } catch {
        status.textContent = "Could not save this draft on this device";
        status.dataset.state = "error";
      }
    };
    form.addEventListener("input", save);
    form.addEventListener("change", save);
    form.addEventListener("reset", () => storage.removeItem(storageKey));
    return { matched: uniqueFields.length, detail: restored ? "draft restored" : "draft storage ready" };
  }
  function ruleFailure(value, rule) {
    if (rule.kind === "required") return value.trim().length === 0;
    if (rule.kind === "email") return value.length > 0 && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
    if (rule.kind === "minLength") return value.length > 0 && value.length < Number(rule.value);
    if (rule.kind === "pattern") {
      try {
        return value.length > 0 && !new RegExp(String(rule.value)).test(value);
      } catch {
        return true;
      }
    }
    return false;
  }
  function setupValidation(operation, context, form) {
    const { document: document2 } = context;
    const pairs = operation.fields.flatMap(
      (field) => selected(document2, field.selector).filter((element) => isEligibleField(element)).map((element) => ({ element, rules: field.rules }))
    );
    const validate = (element, rules) => {
      const existingId = `openpatch-error-${operation.id}-${element.id || element.name || "field"}`.replace(/[^a-z0-9_-]/gi, "-");
      document2.getElementById(existingId)?.remove();
      element.removeAttribute("aria-invalid");
      const originalDescription = (element.getAttribute("aria-describedby") || "").split(/\s+/).filter((id) => id && id !== existingId);
      const failed = rules.find((rule) => ruleFailure(element.value, rule));
      if (!failed) {
        if (originalDescription.length > 0) element.setAttribute("aria-describedby", originalDescription.join(" "));
        else element.removeAttribute("aria-describedby");
        return true;
      }
      const error = document2.createElement("p");
      error.id = existingId;
      error.className = "openpatch-field-error";
      error.dataset.openpatchOwned = "true";
      error.setAttribute("role", "alert");
      error.textContent = failed.message;
      element.setAttribute("aria-invalid", "true");
      element.setAttribute("aria-describedby", [...originalDescription, existingId].join(" "));
      element.insertAdjacentElement("afterend", error);
      return false;
    };
    pairs.forEach(({ element, rules }) => element.addEventListener("blur", () => validate(element, rules)));
    form.addEventListener("submit", (event) => {
      const invalid = pairs.filter(({ element, rules }) => !validate(element, rules));
      if (invalid.length > 0) {
        event.preventDefault();
        invalid[0].element.focus();
      }
    });
    return pairs.length;
  }
  function applyOperation(patch, operation, context) {
    const { document: document2, window: window2 } = context;
    try {
      if (operation.type === "style") {
        const elements = selected(document2, operation.selector);
        if (!viewportMatches(operation, window2)) return { id: operation.id, type: operation.type, matched: elements.length, applied: true, detail: "viewport rule inactive" };
        elements.forEach((element) => Object.entries(operation.styles).forEach(([property, value]) => element.style.setProperty(property, value)));
        return { id: operation.id, type: operation.type, matched: elements.length, applied: elements.length > 0 };
      }
      if (operation.type === "attributes") {
        const elements = selected(document2, operation.selector);
        elements.forEach((element) => Object.entries(operation.attributes).forEach(([name, value]) => element.setAttribute(name, value)));
        return { id: operation.id, type: operation.type, matched: elements.length, applied: elements.length > 0 };
      }
      if (operation.type === "hide") {
        const elements = selected(document2, operation.selector);
        elements.forEach((element) => {
          element.hidden = true;
          element.setAttribute("aria-hidden", "true");
        });
        return { id: operation.id, type: operation.type, matched: elements.length, applied: elements.length > 0 };
      }
      if (operation.type === "move") {
        const elements = selected(document2, operation.selector);
        const targets = selected(document2, operation.target);
        if (targets.length !== 1 || elements.length === 0) return { id: operation.id, type: operation.type, matched: elements.length, applied: false, detail: `expected one target, found ${targets.length}` };
        const target = targets[0];
        elements.forEach((element) => {
          if (operation.position === "before") target.before(element);
          if (operation.position === "after") target.after(element);
          if (operation.position === "prepend") target.prepend(element);
          if (operation.position === "append") target.append(element);
        });
        return { id: operation.id, type: operation.type, matched: elements.length, applied: true };
      }
      if (operation.type === "persistForm") {
        const forms = selected(document2, operation.selector).filter((element) => element.tagName === "FORM");
        if (forms.length !== 1) return { id: operation.id, type: operation.type, matched: forms.length, applied: false, detail: "expected exactly one form" };
        const result = setupPersistence(patch, operation, context, forms[0]);
        return { id: operation.id, type: operation.type, matched: result.matched, applied: result.matched > 0, detail: result.detail };
      }
      if (operation.type === "validation") {
        const forms = selected(document2, operation.selector).filter((element) => element.tagName === "FORM");
        if (forms.length !== 1) return { id: operation.id, type: operation.type, matched: forms.length, applied: false, detail: "expected exactly one form" };
        const count = setupValidation(operation, context, forms[0]);
        return { id: operation.id, type: operation.type, matched: count, applied: count > 0 };
      }
      const containers = selected(document2, operation.container);
      if (containers.length !== 1) return { id: operation.id, type: operation.type, matched: containers.length, applied: false, detail: "expected exactly one navigation container" };
      const items = [...containers[0].querySelectorAll(operation.items)].slice(0, 50);
      items.forEach((item, index) => item.tabIndex = index === 0 ? 0 : -1);
      containers[0].addEventListener("keydown", (event) => {
        const keyboardEvent = event;
        const previousKey = operation.orientation === "horizontal" ? "ArrowLeft" : "ArrowUp";
        const nextKey = operation.orientation === "horizontal" ? "ArrowRight" : "ArrowDown";
        if (![previousKey, nextKey, "Home", "End"].includes(keyboardEvent.key)) return;
        const current = items.indexOf(document2.activeElement);
        if (current < 0) return;
        keyboardEvent.preventDefault();
        let next = keyboardEvent.key === "Home" ? 0 : keyboardEvent.key === "End" ? items.length - 1 : current + (keyboardEvent.key === nextKey ? 1 : -1);
        if (operation.wrap !== false) next = (next + items.length) % items.length;
        else next = Math.max(0, Math.min(items.length - 1, next));
        items.forEach((item, index) => item.tabIndex = index === next ? 0 : -1);
        items[next]?.focus();
      });
      return { id: operation.id, type: operation.type, matched: items.length, applied: items.length > 0 };
    } catch (error) {
      return { id: operation.id, type: operation.type, matched: 0, applied: false, detail: error instanceof Error ? error.message : "operation failed" };
    }
  }
  function applyPatch(patch, context = {}) {
    const documentRef = context.document ?? document;
    const windowRef = context.window ?? window;
    const storageRef = context.storage ?? windowRef.localStorage;
    const marker = `${patch.id}@${patch.version}`;
    installTrustedUiStyles(documentRef);
    const root = documentRef.documentElement;
    const appliedMarkers = new Set((root.dataset.openpatchApplied ?? "").split(/\s+/).filter(Boolean));
    if (appliedMarkers.has(marker)) {
      return { patchId: patch.id, version: patch.version, applied: true, operations: [], healthy: patch.operations.length, total: patch.operations.length, timestamp: Date.now() };
    }
    const operations = patch.operations.map((operation) => applyOperation(patch, operation, { document: documentRef, window: windowRef, storage: storageRef }));
    const healthy = operations.filter((operation) => operation.applied).length;
    appliedMarkers.add(marker);
    root.dataset.openpatchApplied = [...appliedMarkers].join(" ");
    root.classList.add("openpatch-active");
    return {
      patchId: patch.id,
      version: patch.version,
      applied: healthy === operations.length,
      operations,
      healthy,
      total: operations.length,
      timestamp: Date.now()
    };
  }

  // src/core/matcher.ts
  function hostMatches(pattern, host) {
    if (pattern.startsWith("*.")) {
      const suffix = pattern.slice(1);
      return host.endsWith(suffix) && host !== suffix.slice(1);
    }
    return pattern === host;
  }
  function pathMatches(pattern, pathname) {
    if (pattern.endsWith("*")) return pathname.startsWith(pattern.slice(0, -1));
    return pattern === pathname;
  }
  function patchMatchesUrl(patch, url) {
    return patch.match.hosts.some((host) => hostMatches(host, url.hostname)) && patch.match.paths.some((path) => pathMatches(path, url.pathname));
  }

  // src/core/validator.ts
  var CAPABILITIES = /* @__PURE__ */ new Set([
    "layout",
    "accessibility",
    "local-storage",
    "keyboard-navigation",
    "validation",
    "hide-elements",
    "reorganize"
  ]);
  var SAFE_STYLE_PROPERTIES = /* @__PURE__ */ new Set([
    "display",
    "position",
    "inset",
    "top",
    "right",
    "bottom",
    "left",
    "z-index",
    "width",
    "min-width",
    "max-width",
    "height",
    "min-height",
    "max-height",
    "margin",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "padding",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "gap",
    "row-gap",
    "column-gap",
    "grid-template-columns",
    "grid-template-rows",
    "grid-column",
    "grid-row",
    "flex-direction",
    "flex-wrap",
    "align-items",
    "align-content",
    "justify-content",
    "order",
    "overflow",
    "overflow-x",
    "overflow-y",
    "font-size",
    "font-weight",
    "line-height",
    "letter-spacing",
    "text-align",
    "color",
    "background-color",
    "border",
    "border-width",
    "border-style",
    "border-color",
    "border-radius",
    "box-shadow",
    "opacity",
    "visibility",
    "cursor",
    "outline",
    "outline-offset"
  ]);
  var SAFE_ATTRIBUTE = /^(aria-[a-z-]+|role|tabindex|autocomplete|inputmode|title)$/;
  var SAFE_ID = /^[a-z0-9][a-z0-9._-]{2,79}$/;
  var SAFE_VERSION = /^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/i;
  var SAFE_HOST = /^(localhost|127\.0\.0\.1|(?:\*\.)?[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+)$/i;
  var SAFE_PATH = /^\/[a-z0-9._~!$&'()+,;=:@%/-]*\*?$/i;
  var UNSAFE_VALUE = /(javascript\s*:|expression\s*\(|url\s*\(|@import|<\/?script|onerror\s*=|onload\s*=)/i;
  var UNSAFE_SELECTOR = /(^|[\s,>+~])(?:html|head|body|\*)(?:$|[\s,>+~.#[:])|:root\b|:(?:is|where|not|has)\([^)]*\*/i;
  var UNSAFE_PATTERN = /(\\[1-9]|\(\?[=!<]|\([^)]*[+*][^)]*\)[+*?{])/;
  var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
  var text = (value, max) => typeof value === "string" && value.trim().length > 0 && value.length <= max;
  function checkSelector(selector, path, issues) {
    if (!text(selector, 240)) {
      issues.push({ path, message: "must be a non-empty selector under 240 characters" });
      return;
    }
    const value = selector;
    if (UNSAFE_SELECTOR.test(value)) {
      issues.push({ path, message: "may not target document-wide html, head, body, or universal selectors" });
    }
    if (typeof document !== "undefined") {
      try {
        document.createDocumentFragment().querySelector(value);
      } catch {
        issues.push({ path, message: "is not valid CSS selector syntax" });
      }
    }
  }
  function checkOperation(value, index, issues) {
    const base = `operations[${index}]`;
    if (!isRecord(value)) {
      issues.push({ path: base, message: "must be an object" });
      return;
    }
    if (!text(value.id, 80) || !SAFE_ID.test(String(value.id))) {
      issues.push({ path: `${base}.id`, message: "must use 3-80 lowercase letters, numbers, dots, dashes, or underscores" });
    }
    const type = value.type;
    const known = ["style", "attributes", "hide", "move", "persistForm", "validation", "keyboardNavigation"];
    if (typeof type !== "string" || !known.includes(type)) {
      issues.push({ path: `${base}.type`, message: "is not an allowed transformation" });
      return;
    }
    if (["style", "attributes", "hide", "move", "persistForm", "validation"].includes(type)) {
      checkSelector(value.selector, `${base}.selector`, issues);
    }
    if (type === "style") {
      if (!isRecord(value.styles) || Object.keys(value.styles).length === 0 || Object.keys(value.styles).length > 32) {
        issues.push({ path: `${base}.styles`, message: "must contain 1-32 style declarations" });
      } else {
        for (const [property, raw] of Object.entries(value.styles)) {
          if (!SAFE_STYLE_PROPERTIES.has(property)) {
            issues.push({ path: `${base}.styles.${property}`, message: "property is outside the layout allowlist" });
          }
          if (typeof raw !== "string" || raw.length > 160 || UNSAFE_VALUE.test(raw) || /[{};]/.test(raw)) {
            issues.push({ path: `${base}.styles.${property}`, message: "contains an unsafe or invalid CSS value" });
          }
        }
      }
      if (value.when !== void 0) {
        if (!isRecord(value.when)) {
          issues.push({ path: `${base}.when`, message: "must be a viewport constraint object" });
        } else {
          for (const key of ["minWidth", "maxWidth"]) {
            if (value.when[key] !== void 0 && (typeof value.when[key] !== "number" || value.when[key] < 240 || value.when[key] > 5e3)) {
              issues.push({ path: `${base}.when.${key}`, message: "must be between 240 and 5000" });
            }
          }
        }
      }
    }
    if (type === "attributes") {
      if (!isRecord(value.attributes) || Object.keys(value.attributes).length === 0 || Object.keys(value.attributes).length > 20) {
        issues.push({ path: `${base}.attributes`, message: "must contain 1-20 attributes" });
      } else {
        for (const [name, raw] of Object.entries(value.attributes)) {
          if (!SAFE_ATTRIBUTE.test(name)) {
            issues.push({ path: `${base}.attributes.${name}`, message: "only ARIA and safe interaction attributes are allowed" });
          }
          if (typeof raw !== "string" || raw.length > 240 || UNSAFE_VALUE.test(raw)) {
            issues.push({ path: `${base}.attributes.${name}`, message: "contains an unsafe value" });
          }
        }
      }
    }
    if (type === "move") {
      checkSelector(value.target, `${base}.target`, issues);
      if (!["before", "after", "prepend", "append"].includes(String(value.position))) {
        issues.push({ path: `${base}.position`, message: "must be before, after, prepend, or append" });
      }
    }
    if (type === "persistForm") {
      if (!text(value.key, 80) || !/^[a-z0-9._-]+$/i.test(String(value.key))) {
        issues.push({ path: `${base}.key`, message: "must be a stable storage key" });
      }
      if (!Array.isArray(value.include) || value.include.length === 0 || value.include.length > 12) {
        issues.push({ path: `${base}.include`, message: "must list 1-12 field selectors" });
      } else {
        value.include.forEach((selector, i) => checkSelector(selector, `${base}.include[${i}]`, issues));
      }
      if (!Number.isInteger(value.ttlMinutes) || Number(value.ttlMinutes) < 5 || Number(value.ttlMinutes) > 10080) {
        issues.push({ path: `${base}.ttlMinutes`, message: "must expire drafts between 5 minutes and 7 days" });
      }
      if (!text(value.statusText, 120)) {
        issues.push({ path: `${base}.statusText`, message: "must be concise visible status text" });
      }
    }
    if (type === "validation") {
      if (!Array.isArray(value.fields) || value.fields.length === 0 || value.fields.length > 30) {
        issues.push({ path: `${base}.fields`, message: "must define 1-30 fields" });
      } else {
        value.fields.forEach((field, fieldIndex) => {
          const fieldPath = `${base}.fields[${fieldIndex}]`;
          if (!isRecord(field)) {
            issues.push({ path: fieldPath, message: "must be an object" });
            return;
          }
          checkSelector(field.selector, `${fieldPath}.selector`, issues);
          if (!Array.isArray(field.rules) || field.rules.length === 0 || field.rules.length > 5) {
            issues.push({ path: `${fieldPath}.rules`, message: "must define 1-5 rules" });
            return;
          }
          field.rules.forEach((rule, ruleIndex) => {
            const rulePath = `${fieldPath}.rules[${ruleIndex}]`;
            if (!isRecord(rule) || !["required", "email", "minLength", "pattern"].includes(String(rule.kind))) {
              issues.push({ path: rulePath, message: "uses an unsupported validation rule" });
            } else {
              if (!text(rule.message, 180)) issues.push({ path: `${rulePath}.message`, message: "must include an accessible error message" });
              if (rule.kind === "minLength" && (typeof rule.value !== "number" || rule.value < 1 || rule.value > 500)) {
                issues.push({ path: `${rulePath}.value`, message: "must be a number between 1 and 500" });
              }
              if (rule.kind === "pattern" && (!text(rule.value, 120) || UNSAFE_VALUE.test(String(rule.value)))) {
                issues.push({ path: `${rulePath}.value`, message: "must be a safe regular expression" });
              } else if (rule.kind === "pattern") {
                try {
                  if (UNSAFE_PATTERN.test(String(rule.value))) throw new Error("unsafe pattern");
                  new RegExp(String(rule.value));
                } catch {
                  issues.push({ path: `${rulePath}.value`, message: "must be a bounded regular expression without lookarounds, backreferences, or nested quantifiers" });
                }
              }
            }
          });
        });
      }
    }
    if (type === "keyboardNavigation") {
      checkSelector(value.container, `${base}.container`, issues);
      checkSelector(value.items, `${base}.items`, issues);
      if (!["horizontal", "vertical"].includes(String(value.orientation))) {
        issues.push({ path: `${base}.orientation`, message: "must be horizontal or vertical" });
      }
    }
  }
  function validatePatch(value) {
    const issues = [];
    const warnings = [];
    if (!isRecord(value)) return { ok: false, issues: [{ path: "$", message: "patch must be a JSON object" }], warnings };
    if (value.schemaVersion !== 1) issues.push({ path: "schemaVersion", message: "must equal 1" });
    if (!text(value.id, 80) || !SAFE_ID.test(String(value.id))) issues.push({ path: "id", message: "must be a stable lowercase patch id" });
    if (!text(value.name, 80)) issues.push({ path: "name", message: "must be 1-80 characters" });
    if (!text(value.summary, 240)) issues.push({ path: "summary", message: "must be 1-240 characters" });
    if (!text(value.version, 40) || !SAFE_VERSION.test(String(value.version))) issues.push({ path: "version", message: "must be semantic version syntax" });
    if (!isRecord(value.author) || !text(value.author.name, 80)) issues.push({ path: "author.name", message: "must identify the patch author" });
    else if (value.author.verified !== void 0 && typeof value.author.verified !== "boolean") issues.push({ path: "author.verified", message: "must be a boolean when provided" });
    if (!isRecord(value.match)) {
      issues.push({ path: "match", message: "must define exact hosts and paths" });
    } else {
      if (!Array.isArray(value.match.hosts) || value.match.hosts.length === 0 || value.match.hosts.length > 12) {
        issues.push({ path: "match.hosts", message: "must list 1-12 hosts" });
      } else {
        value.match.hosts.forEach((host, index) => {
          if (typeof host !== "string" || !SAFE_HOST.test(host)) issues.push({ path: `match.hosts[${index}]`, message: "must be an exact host or one leftmost subdomain wildcard" });
        });
      }
      if (!Array.isArray(value.match.paths) || value.match.paths.length === 0 || value.match.paths.length > 20) {
        issues.push({ path: "match.paths", message: "must list 1-20 pathname patterns" });
      } else {
        value.match.paths.forEach((path, index) => {
          if (typeof path !== "string" || !SAFE_PATH.test(path) || path.includes("..") || path.slice(0, -1).includes("*")) {
            issues.push({ path: `match.paths[${index}]`, message: "must be a safe pathname with at most one final wildcard" });
          }
        });
      }
    }
    if (!Array.isArray(value.capabilities) || value.capabilities.length === 0) {
      issues.push({ path: "capabilities", message: "must declare at least one capability" });
    } else {
      value.capabilities.forEach((capability, index) => {
        if (!CAPABILITIES.has(capability)) issues.push({ path: `capabilities[${index}]`, message: "is not a recognized capability" });
      });
    }
    if (!Array.isArray(value.operations) || value.operations.length === 0 || value.operations.length > 100) {
      issues.push({ path: "operations", message: "must contain 1-100 constrained operations" });
    } else {
      value.operations.forEach((operation, index) => checkOperation(operation, index, issues));
      const ids = value.operations.map((operation) => isRecord(operation) ? operation.id : void 0).filter(Boolean);
      if (new Set(ids).size !== ids.length) issues.push({ path: "operations", message: "operation ids must be unique" });
      if (Array.isArray(value.capabilities)) {
        const declared = new Set(value.capabilities);
        requiredCapabilities(value.operations).forEach((capability) => {
          if (!declared.has(capability)) issues.push({ path: "capabilities", message: `must declare ${capability} for the requested operations` });
        });
      }
    }
    if (!Array.isArray(value.verify) || value.verify.length === 0) {
      warnings.push({ path: "verify", message: "published patches should include selector assertions" });
    } else if (value.verify.length > 50) {
      issues.push({ path: "verify", message: "must contain no more than 50 assertions" });
    } else {
      value.verify.forEach((assertion, index) => {
        const path = `verify[${index}]`;
        if (!isRecord(assertion) || !["exists", "attribute"].includes(String(assertion.type))) {
          issues.push({ path, message: "must be an exists or attribute assertion" });
          return;
        }
        checkSelector(assertion.selector, `${path}.selector`, issues);
        if (assertion.type === "exists") {
          for (const bound of ["min", "max"]) {
            if (assertion[bound] !== void 0 && (!Number.isInteger(assertion[bound]) || Number(assertion[bound]) < 0 || Number(assertion[bound]) > 100)) {
              issues.push({ path: `${path}.${bound}`, message: "must be an integer between 0 and 100" });
            }
          }
          if (typeof assertion.min === "number" && typeof assertion.max === "number" && assertion.min > assertion.max) {
            issues.push({ path, message: "minimum selector count may not exceed maximum" });
          }
        } else {
          if (!text(assertion.name, 80) || !/^[a-z][a-z0-9:._-]*$/i.test(String(assertion.name))) issues.push({ path: `${path}.name`, message: "must be a safe attribute name" });
          if (typeof assertion.value !== "string" || assertion.value.length > 240 || UNSAFE_VALUE.test(assertion.value)) issues.push({ path: `${path}.value`, message: "must be a safe assertion value" });
        }
      });
    }
    if (!text(value.changelog, 500)) issues.push({ path: "changelog", message: "must describe this version" });
    if (issues.length > 0) return { ok: false, issues, warnings };
    return { ok: true, patch: value, warnings };
  }
  function requiredCapabilities(operations) {
    const result = /* @__PURE__ */ new Set();
    for (const operation of operations) {
      if (operation.type === "style") result.add("layout");
      if (operation.type === "attributes") result.add("accessibility");
      if (operation.type === "hide") result.add("hide-elements");
      if (operation.type === "move") result.add("reorganize");
      if (operation.type === "persistForm") result.add("local-storage");
      if (operation.type === "validation") result.add("validation");
      if (operation.type === "keyboardNavigation") result.add("keyboard-navigation");
    }
    return [...result];
  }

  // src/core/registry.ts
  function versionParts(version) {
    return version.split(/[.-]/).slice(0, 3).map((part) => Number.parseInt(part, 10) || 0);
  }
  function comparePatchVersions(left, right) {
    const a = versionParts(left);
    const b = versionParts(right);
    for (let index = 0; index < 3; index += 1) {
      if (a[index] !== b[index]) return a[index] - b[index];
    }
    return left.localeCompare(right);
  }
  function buildPatchCatalog(bundled2, stored) {
    const byId = /* @__PURE__ */ new Map();
    let rejected = 0;
    for (const patch of bundled2) {
      const validation = validatePatch(patch);
      if (!validation.ok) {
        rejected += 1;
        continue;
      }
      byId.set(patch.id, { patch, source: "bundled" });
    }
    if (stored && typeof stored === "object" && !Array.isArray(stored)) {
      for (const candidate of Object.values(stored)) {
        const validation = validatePatch(candidate);
        if (!validation.ok) {
          rejected += 1;
          continue;
        }
        const current = byId.get(validation.patch.id);
        if (!current || comparePatchVersions(validation.patch.version, current.patch.version) >= 0) {
          byId.set(validation.patch.id, { patch: validation.patch, source: "local" });
        }
      }
    }
    return { patches: [...byId.values()], rejected };
  }
  function matchingCatalogPatches(catalog, url) {
    return catalog.filter(({ patch }) => patchMatchesUrl(patch, url));
  }

  // src/extension/content.ts
  var bundled = [civic_apply_openpatch_default];
  var matches = [];
  async function initialize() {
    const stored = await chrome.storage.local.get(["enabledPatches", "installedPatches"]);
    const enabledPatches = stored.enabledPatches ?? {};
    const catalog = buildPatchCatalog(bundled, stored.installedPatches);
    const matching = matchingCatalogPatches(catalog.patches, new URL(location.href));
    matches = matching.map(({ patch, source }) => {
      const enabled = Boolean(enabledPatches[patch.id]);
      const health = enabled ? applyPatch(patch) : null;
      if (health) void chrome.storage.local.set({ [`health:${patch.id}:${location.hostname}`]: health });
      return {
        enabled,
        health,
        source,
        patch: {
          id: patch.id,
          name: patch.name,
          summary: patch.summary,
          version: patch.version,
          capabilities: patch.capabilities,
          author: patch.author,
          match: patch.match,
          operationCount: patch.operations.length
        }
      };
    });
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "OPENPATCH_GET_STATE") {
      sendResponse({ matched: matches.length > 0, matches });
    }
  });
  void initialize();
})();
//# sourceMappingURL=content.js.map
